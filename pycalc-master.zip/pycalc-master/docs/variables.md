## Variables declaring
To declare a variable, simply type:
```
<name> = <value>
```
For example: 
```
my_constant = (0x5f3759df + 42) >> 8
```

## Get variable value
To get a value of variable, simply type its name. <br>
For example: 
```
my_constant + 5
```
